import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-show-images',
  templateUrl: './show-images.component.html',
  styleUrls: ['./show-images.component.css']
})
export class ShowImagesComponent implements OnInit {
  books: any;
  constructor(private service: BooksService) { }

  ngOnInit(): void {
    this.service.getBooks().subscribe( (result: any) => {console.log(result); this.books = result; });
  }

}


