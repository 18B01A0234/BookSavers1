import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-images',
  templateUrl: './show-images.component.html',
  styleUrls: ['./show-images.component.css']
})
export class ShowImagesComponent implements OnInit {
  books: any;
  constructor(private router:Router,private service: BooksService) {
   }

  ngOnInit(): void {
    this.service.getBooks().subscribe( (result: any) => {console.log(result); this.books = result; });
  }

  Buy() {
    this.router.navigate(['order']);
  }
}


