import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: any;
  retrivedData: any;
  constructor( private booksService: BooksService) {
    this.user = {emailId: '', password: ''};
  }
  ngOnInit() {
  }
  // userLogin(): void {
  //   console.log('Inside user Login method...');
  //   console.log(this.user);
  // }

  login() {
    this.booksService.getUserByUserPass(this.user).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData == null){
      alert("Invalid Credentials");
    }
    else{
      alert("Logged in successfully")
    }
    });
    }

}
