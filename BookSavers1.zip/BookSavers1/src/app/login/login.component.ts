import { Component, NgZone, OnInit } from '@angular/core';
import { BooksService } from './../books.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  auth2:any;
  user: any;
  user1: any;
  retrivedData: any;
  constructor(private router:Router, private booksService: BooksService,private ngZone: NgZone) {
    this.user = {emailId: '', password: ''};
  }
  ngOnInit() {
    this.googleInitialize();
  }
  // userLogin(): void {
  //   console.log('Inside user Login method...');
  //   console.log(this.user);
  // }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '1014767719353-5562fsn2sc79d8katd2hki333rjus5qo.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Email: ' + profile.getEmail());

          this.ngZone.run(() => this.router.navigate(['dashboard'])).then();
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }

  EnCryptpassword(password : string){
    let encryptedText = this.booksService.encrypt(password);
    console.log(encryptedText);
    return encryptedText;
    }
    DeCryptpassword(password : string){
    let decryptedText = this.booksService.decrypt(password);
    console.log("Hi" + decryptedText);
    return decryptedText;
    }


  login() {
    this.booksService.getUserByEmail(this.user).subscribe((result: any) => {console.log(result); this.retrivedData = result;
      console.log(this.retrivedData.password);
      let decrypted_pass = this.DeCryptpassword(this.retrivedData.password);
      console.log(decrypted_pass);
    if(this.user.password != decrypted_pass ||this.retrivedData == null){
      alert("Invalid Credentials");
    }
    else{
      this.router.navigate(['dashboard']);
    }
      localStorage.setItem('firstName',this.retrivedData.firstName);
      localStorage.setItem("email",this.retrivedData.emailId);
      console.log(this.retrivedData);
    });
    }

}
