import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: any;
  constructor(private service: BooksService) {
    this.user = {userId: '', firstName: '', lastName: '', mobile: '', emailId: '', street: '', city : '',state:'', password:''};
   }

  ngOnInit(): void {
  }
  register(): void {
    this.service.registerUser(this.user).subscribe((result: any) => { console.log(result); } );
    console.log(this.user);
  }
}
