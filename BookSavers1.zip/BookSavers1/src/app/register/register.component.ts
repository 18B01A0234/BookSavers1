import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: any;
  constructor(private router:Router, private service: BooksService) {
    this.user = {userId: '', firstName: '', lastName: '', mobile: '', emailId: '', street: '', city : '',state:'', password:''};
   }

  ngOnInit(): void {
  }
  register(): void {
    this.service.registerUser(this.user).subscribe((result: any) => { console.log(result); 
      ;} );
      this.router.navigate(['login'])
    console.log(this.user);
  }
}
