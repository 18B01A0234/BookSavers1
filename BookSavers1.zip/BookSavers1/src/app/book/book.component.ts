import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private service: BooksService) {
    //this.imageUrl = '/assets/img/default-image.png';
  }
  ngOnInit(){
  }
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    console.log('Bookname: ' + imageForm.bookName);
        console.log('CategoryName: ' + imageForm.categoryName);
        console.log('authorName: ' + imageForm.authorName);
        console.log('Image: ' + (this.fileToUpload.name));
        console.log('BookPrice: ' + imageForm.bookPrice);
        console.log('Selltype: ' + imageForm.selltype);
    this.service.postFile(imageForm, this.fileToUpload).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
      }
    );
  }
}
