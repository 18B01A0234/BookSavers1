import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BooksService {
  private isUserLogged: any;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any {
     return this.isUserLogged;
   }
   registerUser(user: any) {
    return this.httpClient.post('RESTAPI_BOOKSAVERS/webapi/myresource/registerUser/', user);
   }

   getUserByUserPass(user : any) {
    console.log(user);
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getUserByUserPass/'+ user.emailId + '/' + user.password);
  }

  getBookByName(book : any){
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getBookByName/'+ book.bookName);
  }

  
   postFile(ImageForm:any,filetoUpload: File){
     const formData: FormData = new FormData();
     
     formData.append('bookName',ImageForm.bookName);
     formData.append('categoryName',ImageForm.categoryName);
     formData.append('authorName',ImageForm.authorName);
     formData.append('bookImage',filetoUpload,filetoUpload.name);
     formData.append('bookPrice',ImageForm.bookPrice);
     formData.append('selltype',ImageForm.selltype);
     return this.httpClient.post('RESTAPI_BOOKSAVERS/webapi/myresource/registerBook/', formData)
   }
   getBooks(){
    return this.httpClient.get('RESTAPI_BOOKSAVERS/webapi/myresource/getBooks');
  }

}

