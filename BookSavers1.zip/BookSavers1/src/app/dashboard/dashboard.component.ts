import { Component, OnInit } from '@angular/core';
import { BooksService } from './../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user:any;
  constructor(private router: Router, private service: BooksService) { 
    this.user = localStorage.getItem("firstName");
  }
  
  ngOnInit(): void {
    
  }
  
  upload() {
      this.router.navigate(['book']);
  }
}
