import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BooksService } from '../books.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  book : any;
  constructor(private router: Router, bookSevice:BooksService) { 
    this.book = localStorage.getItem("bookName");
  }

  ngOnInit(): void {
  }

  Order() {
    this.router.navigate(['dashboard']);
  }
}
